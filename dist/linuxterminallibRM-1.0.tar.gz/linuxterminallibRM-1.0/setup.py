from setuptools import setup

setup(name='linuxterminallibRM',
      version='1.0',
      description='Can run commands in terminal (with sudo too)',
      packages=[''],
      author_email='arcanedevstudio@gmail.com',
      zip_safe=False)