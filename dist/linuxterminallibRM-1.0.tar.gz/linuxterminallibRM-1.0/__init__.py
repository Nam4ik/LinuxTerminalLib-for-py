from setup.cfg import *
from linuxterminalLibRM.cpp import *
